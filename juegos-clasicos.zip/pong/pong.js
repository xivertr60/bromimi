
const canvas = document.getElementById("pong");
const ctx = canvas.getContext("2d");

const paddleWidth = 10, paddleHeight = 100;
let playerY = (canvas.height - paddleHeight) / 2;
let aiY = (canvas.height - paddleHeight) / 2;
let ball = {x: canvas.width/2, y: canvas.height/2, radius: 10, speed: 4, dx: 4, dy: 4};

function drawRect(x, y, w, h, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w, h);
}

function drawCircle(x, y, r, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI*2, false);
    ctx.closePath();
    ctx.fill();
}

canvas.addEventListener("mousemove", e => {
    playerY = e.offsetY - paddleHeight / 2;
});

function update() {
    ball.x += ball.dx;
    ball.y += ball.dy;

    if (ball.y + ball.radius > canvas.height || ball.y - ball.radius < 0) ball.dy *= -1;

    if (ball.x < 10 && ball.y > playerY && ball.y < playerY + paddleHeight) ball.dx *= -1;
    if (ball.x > canvas.width - 20 && ball.y > aiY && ball.y < aiY + paddleHeight) ball.dx *= -1;

    if (ball.x < 0 || ball.x > canvas.width) {
        ball.x = canvas.width/2;
        ball.y = canvas.height/2;
    }

    aiY += (ball.y - (aiY + paddleHeight/2)) * 0.1;
}

function render() {
    drawRect(0, 0, canvas.width, canvas.height, "#000");
    drawRect(0, playerY, paddleWidth, paddleHeight, "#fff");
    drawRect(canvas.width - paddleWidth, aiY, paddleWidth, paddleHeight, "#fff");
    drawCircle(ball.x, ball.y, ball.radius, "#fff");
}

function gameLoop() {
    update();
    render();
    requestAnimationFrame(gameLoop);
}
gameLoop();
